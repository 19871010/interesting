```

(?, 128, 128, 24)
(?, 64, 64, 24)
(?, 64, 64, 96)
(?, 32, 32, 96)
2017-07-29 18:31:20.497520: W tensorflow/core/platform/cpu_feature_guard.cc:45] The TensorFlow library wasn't compiled to use SSE4.2 instructions, but these are available on your machine and could speed up CPU computations.
2017-07-29 18:31:20.497532: W tensorflow/core/platform/cpu_feature_guard.cc:45] The TensorFlow library wasn't compiled to use AVX instructions, but these are available on your machine and could speed up CPU computations.
2017-07-29 18:31:20.497536: W tensorflow/core/platform/cpu_feature_guard.cc:45] The TensorFlow library wasn't compiled to use AVX2 instructions, but these are available on your machine and could speed up CPU computations.
2017-07-29 18:31:20.497540: W tensorflow/core/platform/cpu_feature_guard.cc:45] The TensorFlow library wasn't compiled to use FMA instructions, but these are available on your machine and could speed up CPU computations.
['1-1.jpg', '1-10.jpg', '1-2.jpg', '1-3.jpg', '1-4.jpg', '1-5.jpg', '1-7.jpg', '1-8.jpg', '1-9.jpg', '10-1.jpg', '10-10.jpg', '10-11.jpg', '10-12.jpg', '10-13.jpg', '10-14.jpg', '10-15.jpg', '10-16.jpg', '10-18.jpg', '10-19.jpg', '10-2.jpg', '10-20.jpg', '10-3.jpg', '10-4.jpg', '10-5.jpg', '10-6.jpg', '10-7.jpg', '10-8.jpg', '10-9.jpg', '2-1.jpg', '2-10.jpg', '2-3.jpg', '2-4.jpg', '2-5.jpg', '2-6.jpg', '2-8.jpg', '2-9.jpg', '3-1.jpg', '3-10.jpg', '3-2.jpg', '3-3.jpg', '3-4.jpg', '3-6.jpg', '3-7.jpg', '3-8.jpg', '3-9.jpg', '4-1.jpg', '4-10.jpg', '4-2.jpg', '4-3.jpg', '4-4.jpg', '4-5.jpg', '4-6.jpg', '4-7.jpg', '4-8.jpg', '4-9.jpg', '5-1.jpg', '5-10.jpg', '5-2.jpg', '5-3.jpg', '5-6.jpg', '5-7.jpg', '5-8.jpg', '6-1.jpg', '6-10.jpg', '6-2.jpg', '6-4.jpg', '6-5.jpg', '6-6.jpg', '6-7.jpg', '6-8.jpg', '6-9.jpg', '7-1.jpg', '7-10.jpg', '7-2.jpg', '7-3.jpg', '7-4.jpg', '7-5.jpg', '7-6.jpg', '7-7.jpg', '7-8.jpg', '7-9.jpg', '8-10.jpg', '8-11.jpg', '8-12.jpg', '8-13.jpg', '8-14.jpg', '8-15.jpg', '8-16.jpg', '8-17.jpg', '8-18.jpg', '8-19.jpg', '8-2.jpg', '8-20.jpg', '8-3.jpg', '8-4.jpg', '8-5.jpg', '8-6.jpg', '8-7.jpg', '8-8.jpg', '8-9.jpg', '9-1.jpg', '9-10.jpg', '9-11.jpg', '9-12.jpg', '9-13.jpg', '9-14.jpg', '9-15.jpg', '9-16.jpg', '9-17.jpg', '9-18.jpg', '9-19.jpg', '9-2.jpg', '9-20.jpg', '9-3.jpg', '9-4.jpg', '9-5.jpg', '9-6.jpg', '9-7.jpg', '9-8.jpg', '9-9.jpg']
120
count: 1
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 30, Minibatch Loss= 48161656.000000, Training Accuracy= 0.80000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 60, Minibatch Loss= 321867840.000000, Training Accuracy= 0.00000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 90, Minibatch Loss= 423731744.000000, Training Accuracy= 0.00000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 120, Minibatch Loss= 427380992.000000, Training Accuracy= 0.00000
count: 2
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 150, Minibatch Loss= 212897232.000000, Training Accuracy= 0.00000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 180, Minibatch Loss= 46964744.000000, Training Accuracy= 0.10000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 210, Minibatch Loss= 14519466.000000, Training Accuracy= 0.40000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 240, Minibatch Loss= 9990268.000000, Training Accuracy= 0.60000
count: 3
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 270, Minibatch Loss= 80894400.000000, Training Accuracy= 0.00000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 300, Minibatch Loss= 55994028.000000, Training Accuracy= 0.00000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 330, Minibatch Loss= 71483504.000000, Training Accuracy= 0.00000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 360, Minibatch Loss= 36483064.000000, Training Accuracy= 0.00000
count: 4
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 390, Minibatch Loss= 58645964.000000, Training Accuracy= 0.00000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 420, Minibatch Loss= 48663864.000000, Training Accuracy= 0.00000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 450, Minibatch Loss= 17381402.000000, Training Accuracy= 0.10000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 480, Minibatch Loss= 2577538.500000, Training Accuracy= 0.70000
count: 5
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 510, Minibatch Loss= 15052680.000000, Training Accuracy= 0.40000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 540, Minibatch Loss= 18420312.000000, Training Accuracy= 0.20000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 570, Minibatch Loss= 23141172.000000, Training Accuracy= 0.10000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 600, Minibatch Loss= 10837658.000000, Training Accuracy= 0.40000
count: 6
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 630, Minibatch Loss= 21745000.000000, Training Accuracy= 0.30000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 660, Minibatch Loss= 17480332.000000, Training Accuracy= 0.40000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 690, Minibatch Loss= 17633370.000000, Training Accuracy= 0.10000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 720, Minibatch Loss= 10235282.000000, Training Accuracy= 0.30000
count: 7
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 750, Minibatch Loss= 6799557.000000, Training Accuracy= 0.80000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 780, Minibatch Loss= 4268240.000000, Training Accuracy= 0.70000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 810, Minibatch Loss= 575766.312500, Training Accuracy= 0.90000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 840, Minibatch Loss= 6839501.000000, Training Accuracy= 0.50000
count: 8
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 870, Minibatch Loss= 19500750.000000, Training Accuracy= 0.30000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 900, Minibatch Loss= 11227581.000000, Training Accuracy= 0.60000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 930, Minibatch Loss= 14566576.000000, Training Accuracy= 0.20000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 960, Minibatch Loss= 5684557.500000, Training Accuracy= 0.40000
count: 9
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 990, Minibatch Loss= 7205131.000000, Training Accuracy= 0.80000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 1020, Minibatch Loss= 5167798.000000, Training Accuracy= 0.70000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 1050, Minibatch Loss= 0.000000, Training Accuracy= 1.00000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 1080, Minibatch Loss= 394604.187500, Training Accuracy= 0.90000
count: 10
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 1110, Minibatch Loss= 3477911.250000, Training Accuracy= 0.70000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 1140, Minibatch Loss= 293735.093750, Training Accuracy= 0.90000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 1170, Minibatch Loss= 3111549.500000, Training Accuracy= 0.80000
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
(10, 128, 128, 3)
(10, 10)
Iter 1200, Minibatch Loss= 0.000000, Training Accuracy= 1.00000
Optimization Finished!

Process finished with exit code 0


```
