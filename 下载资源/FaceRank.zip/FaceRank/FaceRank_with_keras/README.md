# FaceRank预训练模型测试

----------
感谢@fendouai辛苦标注图片颜值信息，由于本人擅长使用keras，于是将@fendouai的项目改成keras版本，同时训练模型已经上传，且有使用实例在notebook中，谢谢大家。

